import{c as m,a as i}from"./R8eUw0rf.js";import{f as n}from"./Ckx13BoS.js";import{s as p}from"./Dyoa9UM_.js";function c(a,o){var r=m(),t=n(r);p(t,()=>o.children),i(a,r)}export{c as L};
