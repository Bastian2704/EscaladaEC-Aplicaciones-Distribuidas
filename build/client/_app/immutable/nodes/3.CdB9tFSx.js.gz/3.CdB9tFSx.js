import{L as m}from"../chunks/CAmZEJkh.js";export{m as component};
